# Sales & Revenue Analysis Dashboard

## Project Overview
This project analyzes sales and revenue data using Power BI.

## Features
- Sales KPI Tracking
- Revenue Analysis
- Product Performance Analysis
- Region-wise Revenue Analysis
- Interactive Filters and Slicers

## Tools Used
- Power BI
- Microsoft Excel

## Dashboard Components
- Total Sales
- Total Revenue
- Total Products
- Revenue Trend Chart
- Product Revenue Analysis
- Region Revenue Analysis

## Outcome
This dashboard helps businesses monitor sales performance, identify top-performing products, and generate business insights through interactive visualizations.